#!/bin/bash
set -e

echo "== Minecraft Server bootstrap (Auto-Updating) =="

# 0. /data 準備と基本権限
if [ ! -d /data ]; then
  mkdir -p /data
fi
chown -R minecraft:minecraft /data
cd /data

echo "EULA accepted: ${EULA}"
echo "JAVA_HOME: ${JAVA_HOME}"
echo "================================"

# 1. EULAチェック
if [ "${EULA}" != "TRUE" ]; then
  echo "[ERROR] EULA not accepted."
  echo "Please set EULA=TRUE in docker-compose.yml or environment variables."
  exit 1
fi

# eula.txt を minecraft 所有で作成
echo "eula=true" > eula.txt
chown minecraft:minecraft eula.txt

# 2. Minecraftサーバーの自動更新処理
echo "[INFO] Checking for latest Minecraft server version..."

# 最新バージョン情報を取得
curl -s https://launchermeta.mojang.com/mc/game/version_manifest.json -o version_manifest.json
LATEST_VER=$(jq -r '.latest.release' version_manifest.json)
echo "[INFO] Latest release version: ${LATEST_VER}"

# 最新バージョンのURLを取得
URL=$(jq -r --arg v "$LATEST_VER" '.versions[] | select(.id==$v) | .url' version_manifest.json)
curl -s "$URL" -o version.json
JAR_URL=$(jq -r '.downloads.server.url' version.json)
JAR_SHA1=$(jq -r '.downloads.server.sha1' version.json)

# 既存server.jarのハッシュ比較
if [ ! -f server.jar ]; then
  echo "[INFO] No existing server.jar found. Downloading fresh copy..."
  wget -q "$JAR_URL" -O server.jar
elif [ "$(sha1sum server.jar | awk '{print $1}')" != "$JAR_SHA1" ]; then
  echo "[INFO] Detected new server version. Updating..."
  mv server.jar server.jar.bak_$(date +%Y%m%d_%H%M%S)
  wget -q "$JAR_URL" -O server.jar
else
  echo "[INFO] server.jar is already up to date."
fi

chown minecraft:minecraft server.jar version.json version_manifest.json

# 3. 初期生成フェーズ（worldや設定ファイルがない場合のみ）
if [ ! -d world ]; then
  echo "[INFO] Running warm-up init to generate world and config files..."
  su -s /bin/bash minecraft -c "java -Xms1G -Xmx1G -jar /data/server.jar nogui" &
  WARMUP_PID=$!
  sleep 5
  kill -TERM $WARMUP_PID || true
  sleep 2
  echo "[INFO] Warm-up init complete."
fi

# 4. 権限をminecraftに統一
chown -R minecraft:minecraft /data

# whitelist.json だけwww-dataグループにして書き込み許可
if [ -f /data/whitelist.json ]; then
  chown minecraft:www-data /data/whitelist.json || true
  chmod 660 /data/whitelist.json || true
fi

echo "[INFO] Permission setup complete."
echo "[INFO] Launching Minecraft server (final)..."

# 5. 本番起動（フォアグラウンドで常駐）
exec su -s /bin/bash minecraft -c "java -Xms1G -Xmx4G -Duser.timezone=Asia/Tokyo -jar /data/server.jar nogui"
