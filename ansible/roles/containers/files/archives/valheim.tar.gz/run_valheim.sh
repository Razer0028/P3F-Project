#!/bin/bash
set -euo pipefail

SERVER_NAME="${SERVER_NAME:-Valheim_PublicServer}"
WORLD_NAME="${WORLD_NAME:-ValheimWorld}"
SERVER_PASS="${SERVER_PASS:-changeme1234}"
SERVER_PORT="${SERVER_PORT:-2456}"
PUBLIC="${PUBLIC:-1}"

VALHEIMDIR="${VALHEIMDIR:-/valheim}"
SAVE_DIR="${SAVE_DIR:-/valheim/saves}"
STEAMCMDDIR="${STEAMCMDDIR:-/steamcmd}"

export SteamAppId=892970

echo "[BOOT] Preparing data dir..."
mkdir -p "${VALHEIMDIR}" "${SAVE_DIR}"

# 権限をvalheimユーザー(UID=1000/GID=1000想定)に揃える
chown -R valheim:valheim "${VALHEIMDIR}"

cd "${VALHEIMDIR}"

echo "[BOOT] Updating server files via SteamCMD..."
# ⚠ ここが重要：+force_install_dir が +login より前
su -s /bin/bash valheim -c "
  \"${STEAMCMDDIR}/steamcmd.sh\" \
    +force_install_dir \"${VALHEIMDIR}\" \
    +login anonymous \
    +app_update 896660 validate \
    +quit
"

# Valheimサーバー実行に必要なライブラリパス
export LD_LIBRARY_PATH="${VALHEIMDIR}/linux64:${LD_LIBRARY_PATH:-}"

echo '[BOOT] ===== Launch Info ====='
echo "[BOOT] Name    : ${SERVER_NAME}"
echo "[BOOT] World   : ${WORLD_NAME}"
echo "[BOOT] Port    : ${SERVER_PORT}"
echo "[BOOT] Public  : ${PUBLIC}"
echo "[BOOT] Pass    : ${SERVER_PASS}"
echo "[BOOT] SaveDir : ${SAVE_DIR}"
echo "[BOOT] Bin     : ${VALHEIMDIR}/valheim_server.x86_64"
echo "[BOOT] ====================================="

# 最終的なサーバー常駐プロセス（PID1になる）
exec su -s /bin/bash valheim -c "
  exec \"${VALHEIMDIR}/valheim_server.x86_64\" \
    -nographics -batchmode \
    -name \"${SERVER_NAME}\" \
    -port \"${SERVER_PORT}\" \
    -world \"${WORLD_NAME}\" \
    -password \"${SERVER_PASS}\" \
    -public \"${PUBLIC}\" \
    -savedir \"${SAVE_DIR}\"
"
