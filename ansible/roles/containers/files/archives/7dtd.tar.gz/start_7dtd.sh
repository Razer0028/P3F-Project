# /home/gameadmin/7dtd_server/start_7dtd.sh
#!/bin/bash
set -euo pipefail

TZ="${TZ:-Asia/Tokyo}"
CONFIG_FILE="${CONFIG_FILE:-/7dtd/serverfiles/serverconfig.xml}"
SDTD_DIR="${SDTD_DIR:-/7dtd/serverfiles}"

DATA_ROOT="/7dtd/data"
HOME_DIR="${DATA_ROOT}/home"
SAVE_DIR="${DATA_ROOT}/saves"
STEAM_DIR="/steamcmd"

APP_ID="294420"
SERVER_PASS="${SERVER_PASS:-changeme1234}"

REQUIRED_MAPCOUNT="${REQUIRED_MAPCOUNT:-262144}"
AUTO_FIX_MAPCOUNT="${AUTO_FIX_MAPCOUNT:-1}"
STRICT_MAPCOUNT="${STRICT_MAPCOUNT:-0}"

log(){ echo "[$(date '+%Y-%m-%dT%H:%M:%S%z')] $*"; }

# タイムゾーン
ln -snf "/usr/share/zoneinfo/$TZ" /etc/localtime && echo "$TZ" >/etc/timezone

# ディレクトリ作成＆権限（コンテナ内は sdtd:sdtd）
mkdir -p "$SDTD_DIR" "$SAVE_DIR" "$HOME_DIR/.local/share" "$HOME_DIR/.config" /7dtd/logs
chown -R sdtd:sdtd "$SDTD_DIR" "$DATA_ROOT" /7dtd/logs || true

export LD_LIBRARY_PATH="${SDTD_DIR}:${LD_LIBRARY_PATH:-}"

# vm.max_map_count チェック（強制はしない）
check_mapcount() {
  local current=0
  if [ -r /proc/sys/vm/max_map_count ]; then
    current="$(cat /proc/sys/vm/max_map_count || echo 0)"
  else
    log "[WARN] Cannot read /proc/sys/vm/max_map_count (container restriction)."
    return 0
  fi

  if [ "$current" -lt "$REQUIRED_MAPCOUNT" ]; then
    log "[WARN] vm.max_map_count is $current (< $REQUIRED_MAPCOUNT). Unity/Mono apps may crash."
    if [ "$AUTO_FIX_MAPCOUNT" = "1" ]; then
      log "[INFO] Trying to raise vm.max_map_count to $REQUIRED_MAPCOUNT ..."
      if command -v sysctl >/dev/null 2>&1; then
        sysctl -w vm.max_map_count="$REQUIRED_MAPCOUNT" 2>/dev/null && log "[OK] Applied via sysctl." && return 0
      fi
      echo "$REQUIRED_MAPCOUNT" > /proc/sys/vm/max_map_count 2>/dev/null && log "[OK] Applied by writing to /proc." && return 0
      log "[WARN] Could not change vm.max_map_count from inside container."
      log "       Please run on the HOST:"
      log "         sudo sysctl -w vm.max_map_count=$REQUIRED_MAPCOUNT"
      log "         echo 'vm.max_map_count=$REQUIRED_MAPCOUNT' | sudo tee /etc/sysctl.d/99-7dtd.conf"
      log "         sudo sysctl --system"
      [ "$STRICT_MAPCOUNT" = "1" ] && log "[ERROR] STRICT_MAPCOUNT=1: refusing to start." && exit 78
    else
      [ "$STRICT_MAPCOUNT" = "1" ] && log "[ERROR] STRICT_MAPCOUNT=1: refusing to start." && exit 78
    fi
  else
    log "[OK] vm.max_map_count=$current (>= $REQUIRED_MAPCOUNT)."
  fi
}
check_mapcount

# 起動毎に SteamCMD で更新（sdtd ユーザーで実行）
if [ -x "${STEAM_DIR}/steamcmd.sh" ]; then
  log "[INFO] Updating 7DTD via steamcmd..."
  su -s /bin/bash sdtd -c "
    HOME='${HOME_DIR}' \
    '${STEAM_DIR}/steamcmd.sh' \
      +@ShutdownOnFailedCommand 1 \
      +force_install_dir '${SDTD_DIR}' \
      +login anonymous \
      +app_update '${APP_ID}' validate \
      +quit
  " || log '[WARN] SteamCMD update failed, using existing files.'
else
  log "[WARN] ${STEAM_DIR}/steamcmd.sh not found. Skipping update."
fi

# serverconfig.xml にパスワード注入/更新
if [ -f "${CONFIG_FILE}" ]; then
  log "[INFO] Applying server password ..."
  if grep -q 'name="ServerPassword"' "${CONFIG_FILE}"; then
    sed -i "s|<property name=\"ServerPassword\".*|<property name=\"ServerPassword\" value=\"${SERVER_PASS}\" />|" "${CONFIG_FILE}"
  else
    sed -i "/name=\"ServerName\"/a <property name=\"ServerPassword\" value=\"${SERVER_PASS}\" />" "${CONFIG_FILE}"
  fi
fi

# ログを docker logs に中継
GAME_LOG="/7dtd/logs/7dtd.log"
: > "${GAME_LOG}"
chmod 664 "${GAME_LOG}"
su -s /bin/bash sdtd -c "tail -n+1 -F '${GAME_LOG}'" &
TAIL_PID=$!
trap 'kill -TERM ${TAIL_PID} 2>/dev/null || true' EXIT

# サーバー起動（HOME/XDG を data に固定）
cd "${SDTD_DIR}"
log "[INFO] Launching 7DTD..."
exec su -s /bin/bash sdtd -c "
  HOME='${HOME_DIR}' \
  XDG_DATA_HOME='${HOME_DIR}/.local/share' \
  XDG_CONFIG_HOME='${HOME_DIR}/.config' \
  exec './7DaysToDieServer.x86_64' \
    -batchmode -nographics \
    -configfile='${CONFIG_FILE}' \
    -logfile '${GAME_LOG}'
"
